import importlib.metadata

__author__ = """Muhammad Rafi"""
__version__ = importlib.metadata.version("conf_diff")
